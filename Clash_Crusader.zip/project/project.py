import pygame
import random
pygame.init()
pygame.display.set_mode((1300,650))
window=pygame.display.set_mode((1300,650))
class button():
    def __init__(self,color,x,y,width,height,text):
        self.color=color
        self.text=text
        self.x=x
        self.y=y
        self.width=width
        self.height=height
    def draw(self,window):
        pygame.draw.rect(window,self.color,(self.x,self.y,self.width,self.height),0)
        font=pygame.font.SysFont('comicsans',30)
        note=font.render(self.text,1,(139,0,0))
        window.blit(note,(self.x + (self.width/2 -note.get_width()/2),self.y+(self.height - note.get_height())/2))
    def mouseonbutton(self,position):
        if position[0]>self.x and position[0]<self.x + self.width:
            if position[1]>self.y and position[1]<self.y + self.height:
                return True
        return False
class button1():
    def __init__(self,x,y,width,height,text):
        self.text=text
        self.x=x
        self.y=y
        self.width=width
        self.height=height
    def draw(self,window):
        pygame.draw.rect(window,(120,120,120),(self.x,self.y,self.width,self.height),1)
        font=pygame.font.SysFont('comicsans',30)
        note=font.render(self.text,1,(102,204,255))
        window.blit(note,(self.x + (self.width/2 -note.get_width()/2),self.y+(self.height - note.get_height())/2))
    def mouseonbutton(self,position):
        if position[0]>self.x and position[0]<self.x + self.width:
            if position[1]>self.y and position[1]<self.y + self.height:
                return True
        return False

arabarcherright=[pygame.image.load('arabarcher/right/1.png'),pygame.image.load('arabarcher/right/2.png'),pygame.image.load('arabarcher/right/3.png'),pygame.image.load('arabarcher/right/4.png'),pygame.image.load('arabarcher/right/5.png'),pygame.image.load('arabarcher/right/6.png'),pygame.image.load('arabarcher/right/7.png'),pygame.image.load('arabarcher/right/8.png')]
arabarcherfront=[pygame.image.load('arabarcher/front/1.png'),pygame.image.load('arabarcher/front/2.png'),pygame.image.load('arabarcher/front/3.png'),pygame.image.load('arabarcher/front/4.png'),pygame.image.load('arabarcher/front/5.png'),pygame.image.load('arabarcher/front/6.png'),pygame.image.load('arabarcher/front/7.png'),pygame.image.load('arabarcher/front/8.png')]
arabarcherleft=[pygame.image.load('arabarcher/left/1.png'),pygame.image.load('arabarcher/left/2.png'),pygame.image.load('arabarcher/left/3.png'),pygame.image.load('arabarcher/left/4.png'),pygame.image.load('arabarcher/left/5.png'),pygame.image.load('arabarcher/left/6.png'),pygame.image.load('arabarcher/left/7.png'),pygame.image.load('arabarcher/left/8.png')]
arabarcheraright=[pygame.image.load('arabarcher/aright/1.png'),pygame.image.load('arabarcher/aright/2.png'),pygame.image.load('arabarcher/aright/3.png'),pygame.image.load('arabarcher/aright/4.png'),pygame.image.load('arabarcher/aright/5.png'),pygame.image.load('arabarcher/aright/6.png'),pygame.image.load('arabarcher/aright/7.png'),pygame.image.load('arabarcher/aright/8.png')]
arabarcherafront=[pygame.image.load('arabarcher/afront/1.png'),pygame.image.load('arabarcher/afront/2.png'),pygame.image.load('arabarcher/afront/3.png'),pygame.image.load('arabarcher/afront/4.png'),pygame.image.load('arabarcher/afront/5.png'),pygame.image.load('arabarcher/afront/6.png'),pygame.image.load('arabarcher/afront/7.png'),pygame.image.load('arabarcher/afront/8.png')]
arabarcheraleft=[pygame.image.load('arabarcher/aleft/1.png'),pygame.image.load('arabarcher/aleft/2.png'),pygame.image.load('arabarcher/aleft/3.png'),pygame.image.load('arabarcher/aleft/4.png'),pygame.image.load('arabarcher/aleft/5.png'),pygame.image.load('arabarcher/aleft/6.png'),pygame.image.load('arabarcher/aleft/7.png'),pygame.image.load('arabarcher/aleft/8.png')]
arabarcherdeath=[pygame.image.load('arabarcher/death/1.png'),pygame.image.load('arabarcher/death/2.png'),pygame.image.load('arabarcher/death/3.png'),pygame.image.load('arabarcher/death/4.png'),pygame.image.load('arabarcher/death/5.png'),pygame.image.load('arabarcher/death/6.png'),pygame.image.load('arabarcher/death/7.png'),pygame.image.load('arabarcher/death/8.png')]
arabarcherback=[pygame.image.load('arabarcher/back/1.png'),pygame.image.load('arabarcher/back/2.png'),pygame.image.load('arabarcher/back/3.png'),pygame.image.load('arabarcher/back/4.png'),pygame.image.load('arabarcher/back/5.png'),pygame.image.load('arabarcher/back/6.png'),pygame.image.load('arabarcher/back/7.png'),pygame.image.load('arabarcher/back/8.png')]
arabarcheraback=[pygame.image.load('arabarcher/aback/1.png'),pygame.image.load('arabarcher/aback/2.png'),pygame.image.load('arabarcher/aback/3.png'),pygame.image.load('arabarcher/aback/4.png'),pygame.image.load('arabarcher/aback/5.png'),pygame.image.load('arabarcher/aback/6.png'),pygame.image.load('arabarcher/aback/7.png'),pygame.image.load('arabarcher/aback/8.png')]

macemanfront=[pygame.image.load('maceman/front/1.png'),pygame.image.load('maceman/front/2.png'),pygame.image.load('maceman/front/3.png'),pygame.image.load('maceman/front/4.png'),pygame.image.load('maceman/front/5.png'),pygame.image.load('maceman/front/6.png'),pygame.image.load('maceman/front/7.png'),pygame.image.load('maceman/front/8.png')]
macemanleft=[pygame.image.load('maceman/left/1.png'),pygame.image.load('maceman/left/2.png'),pygame.image.load('maceman/left/3.png'),pygame.image.load('maceman/left/4.png'),pygame.image.load('maceman/left/5.png'),pygame.image.load('maceman/left/6.png'),pygame.image.load('maceman/left/7.png'),pygame.image.load('maceman/left/8.png')]
macemanaright=[pygame.image.load('maceman/aright/1.png'),pygame.image.load('maceman/aright/2.png'),pygame.image.load('maceman/aright/3.png'),pygame.image.load('maceman/aright/4.png'),pygame.image.load('maceman/aright/5.png'),pygame.image.load('maceman/aright/6.png'),pygame.image.load('maceman/aright/7.png'),pygame.image.load('maceman/aright/8.png')]
macemanafront=[pygame.image.load('maceman/afront/1.png'),pygame.image.load('maceman/afront/2.png'),pygame.image.load('maceman/afront/3.png'),pygame.image.load('maceman/afront/4.png'),pygame.image.load('maceman/afront/5.png'),pygame.image.load('maceman/afront/6.png'),pygame.image.load('maceman/afront/7.png'),pygame.image.load('maceman/afront/8.png')]
macemanaleft=[pygame.image.load('maceman/aleft/1.png'),pygame.image.load('maceman/aleft/2.png'),pygame.image.load('maceman/aleft/3.png'),pygame.image.load('maceman/aleft/4.png'),pygame.image.load('maceman/aleft/5.png'),pygame.image.load('maceman/aleft/6.png'),pygame.image.load('maceman/aleft/7.png'),pygame.image.load('maceman/aleft/8.png')]
macemandeath=[pygame.image.load('maceman/death/1.png'),pygame.image.load('maceman/death/2.png'),pygame.image.load('maceman/death/3.png'),pygame.image.load('maceman/death/4.png'),pygame.image.load('maceman/death/5.png'),pygame.image.load('maceman/death/6.png'),pygame.image.load('maceman/death/7.png'),pygame.image.load('maceman/death/8.png')]
macemanback=[pygame.image.load('maceman/back/1.png'),pygame.image.load('maceman/back/2.png'),pygame.image.load('maceman/back/3.png'),pygame.image.load('maceman/back/4.png'),pygame.image.load('maceman/back/5.png'),pygame.image.load('maceman/back/6.png'),pygame.image.load('maceman/back/7.png'),pygame.image.load('maceman/back/8.png')]
macemanaback=[pygame.image.load('maceman/aback/1.png'),pygame.image.load('maceman/aback/2.png'),pygame.image.load('maceman/aback/3.png'),pygame.image.load('maceman/aback/4.png'),pygame.image.load('maceman/aback/5.png'),pygame.image.load('maceman/aback/6.png'),pygame.image.load('maceman/aback/7.png'),pygame.image.load('maceman/aback/8.png')]
macemanright=[pygame.image.load('maceman/right/1.png'),pygame.image.load('maceman/right/2.png'),pygame.image.load('maceman/right/3.png'),pygame.image.load('maceman/right/4.png'),pygame.image.load('maceman/right/5.png'),pygame.image.load('maceman/right/6.png'),pygame.image.load('maceman/right/7.png'),pygame.image.load('maceman/right/8.png')]
  
swardsmanright=[pygame.image.load('swardsman/right/1.png'),pygame.image.load('swardsman/right/2.png'),pygame.image.load('swardsman/right/3.png'),pygame.image.load('swardsman/right/4.png'),pygame.image.load('swardsman/right/5.png'),pygame.image.load('swardsman/right/6.png'),pygame.image.load('swardsman/right/7.png'),pygame.image.load('swardsman/right/8.png')]
swardsmanfront=[pygame.image.load('swardsman/front/1.png'),pygame.image.load('swardsman/front/2.png'),pygame.image.load('swardsman/front/3.png'),pygame.image.load('swardsman/front/4.png'),pygame.image.load('swardsman/front/5.png'),pygame.image.load('swardsman/front/6.png'),pygame.image.load('swardsman/front/7.png'),pygame.image.load('swardsman/front/8.png')]
swardsmanleft=[pygame.image.load('swardsman/left/1.png'),pygame.image.load('swardsman/left/2.png'),pygame.image.load('swardsman/left/3.png'),pygame.image.load('swardsman/left/4.png'),pygame.image.load('swardsman/left/5.png'),pygame.image.load('swardsman/left/6.png'),pygame.image.load('swardsman/left/7.png'),pygame.image.load('swardsman/left/8.png')]
swardsmanaright=[pygame.image.load('swardsman/aright/1.png'),pygame.image.load('swardsman/aright/2.png'),pygame.image.load('swardsman/aright/3.png'),pygame.image.load('swardsman/aright/4.png'),pygame.image.load('swardsman/aright/5.png'),pygame.image.load('swardsman/aright/6.png'),pygame.image.load('swardsman/aright/7.png'),pygame.image.load('swardsman/aright/8.png')]
swardsmanafront=[pygame.image.load('swardsman/afront/1.png'),pygame.image.load('swardsman/afront/2.png'),pygame.image.load('swardsman/afront/3.png'),pygame.image.load('swardsman/afront/4.png'),pygame.image.load('swardsman/afront/5.png'),pygame.image.load('swardsman/afront/6.png'),pygame.image.load('swardsman/afront/7.png'),pygame.image.load('swardsman/afront/8.png')]
swardsmanaleft=[pygame.image.load('swardsman/aleft/1.png'),pygame.image.load('swardsman/aleft/2.png'),pygame.image.load('swardsman/aleft/3.png'),pygame.image.load('swardsman/aleft/4.png'),pygame.image.load('swardsman/aleft/5.png'),pygame.image.load('swardsman/aleft/6.png'),pygame.image.load('swardsman/aleft/7.png'),pygame.image.load('swardsman/aleft/8.png')]
swardsmandeath=[pygame.image.load('swardsman/death/1.png'),pygame.image.load('swardsman/death/2.png'),pygame.image.load('swardsman/death/3.png'),pygame.image.load('swardsman/death/4.png'),pygame.image.load('swardsman/death/5.png'),pygame.image.load('swardsman/death/6.png'),pygame.image.load('swardsman/death/7.png'),pygame.image.load('swardsman/death/8.png')]
swardsmanback=[pygame.image.load('swardsman/back/1.png'),pygame.image.load('swardsman/back/2.png'),pygame.image.load('swardsman/back/3.png'),pygame.image.load('swardsman/back/4.png'),pygame.image.load('swardsman/back/5.png'),pygame.image.load('swardsman/back/6.png'),pygame.image.load('swardsman/back/7.png'),pygame.image.load('swardsman/back/8.png')]
swardsmanaback=[pygame.image.load('swardsman/aback/1.png'),pygame.image.load('swardsman/aback/2.png'),pygame.image.load('swardsman/aback/3.png'),pygame.image.load('swardsman/aback/4.png'),pygame.image.load('swardsman/aback/5.png'),pygame.image.load('swardsman/aback/6.png'),pygame.image.load('swardsman/aback/7.png'),pygame.image.load('swardsman/aback/8.png')]

mangonelafront=[pygame.image.load('mangonel/afront/1.png'),pygame.image.load('mangonel/afront/2.png'),pygame.image.load('mangonel/afront/3.png'),pygame.image.load('mangonel/afront/4.png'),pygame.image.load('mangonel/afront/5.png'),pygame.image.load('mangonel/afront/6.png'),pygame.image.load('mangonel/afront/7.png'),pygame.image.load('mangonel/afront/8.png')]
mangonelaback=[pygame.image.load('mangonel/aback/1.png'),pygame.image.load('mangonel/aback/2.png'),pygame.image.load('mangonel/aback/3.png'),pygame.image.load('mangonel/aback/4.png'),pygame.image.load('mangonel/aback/5.png'),pygame.image.load('mangonel/aback/6.png'),pygame.image.load('mangonel/aback/7.png'),pygame.image.load('mangonel/aback/8.png')]

monkleft=[pygame.image.load('monk/left/1.png'),pygame.image.load('monk/left/2.png'),pygame.image.load('monk/left/3.png'),pygame.image.load('monk/left/4.png'),pygame.image.load('monk/left/5.png'),pygame.image.load('monk/left/6.png'),pygame.image.load('monk/left/7.png'),pygame.image.load('monk/left/8.png')]
monkright=[pygame.image.load('monk/right/1.png'),pygame.image.load('monk/right/2.png'),pygame.image.load('monk/right/3.png'),pygame.image.load('monk/right/4.png'),pygame.image.load('monk/right/5.png'),pygame.image.load('monk/right/6.png'),pygame.image.load('monk/right/7.png'),pygame.image.load('monk/right/8.png')]
monkdeath=[pygame.image.load('monk/death/1.png'),pygame.image.load('monk/death/2.png'),pygame.image.load('monk/death/3.png'),pygame.image.load('monk/death/4.png'),pygame.image.load('monk/death/5.png'),pygame.image.load('monk/death/6.png'),pygame.image.load('monk/death/7.png'),pygame.image.load('monk/death/8.png')]
monkback=[pygame.image.load('monk/back/1.png'),pygame.image.load('monk/back/2.png'),pygame.image.load('monk/back/3.png'),pygame.image.load('monk/back/4.png'),pygame.image.load('monk/back/5.png'),pygame.image.load('monk/back/6.png'),pygame.image.load('monk/back/7.png'),pygame.image.load('monk/back/8.png')]
monkaback=[pygame.image.load('monk/aback/1.png'),pygame.image.load('monk/aback/2.png'),pygame.image.load('monk/aback/3.png'),pygame.image.load('monk/aback/4.png'),pygame.image.load('monk/aback/5.png'),pygame.image.load('monk/aback/6.png'),pygame.image.load('monk/aback/7.png'),pygame.image.load('monk/aback/8.png')]

assassinleft=[pygame.image.load('assassin/left/1.png'),pygame.image.load('assassin/left/2.png'),pygame.image.load('assassin/left/3.png'),pygame.image.load('assassin/left/4.png'),pygame.image.load('assassin/left/5.png'),pygame.image.load('assassin/left/6.png'),pygame.image.load('assassin/left/7.png'),pygame.image.load('assassin/left/8.png')]
assassinright=[pygame.image.load('assassin/right/1.png'),pygame.image.load('assassin/right/2.png'),pygame.image.load('assassin/right/3.png'),pygame.image.load('assassin/right/4.png'),pygame.image.load('assassin/right/5.png'),pygame.image.load('assassin/right/6.png'),pygame.image.load('assassin/right/7.png'),pygame.image.load('assassin/right/8.png')]
assassindeath=[pygame.image.load('assassin/death/1.png'),pygame.image.load('assassin/death/2.png'),pygame.image.load('assassin/death/3.png'),pygame.image.load('assassin/death/4.png'),pygame.image.load('assassin/death/5.png'),pygame.image.load('assassin/death/6.png'),pygame.image.load('assassin/death/7.png'),pygame.image.load('assassin/death/8.png')]
assassinback=[pygame.image.load('assassin/back/1.png'),pygame.image.load('assassin/back/2.png'),pygame.image.load('assassin/back/3.png'),pygame.image.load('assassin/back/4.png'),pygame.image.load('assassin/back/5.png'),pygame.image.load('assassin/back/6.png'),pygame.image.load('assassin/back/7.png'),pygame.image.load('assassin/back/8.png')]
assassinaback=[pygame.image.load('assassin/aback/1.png'),pygame.image.load('assassin/aback/2.png'),pygame.image.load('assassin/aback/3.png'),pygame.image.load('assassin/aback/4.png'),pygame.image.load('assassin/aback/5.png'),pygame.image.load('assassin/aback/6.png'),pygame.image.load('assassin/aback/7.png'),pygame.image.load('assassin/aback/8.png')]

archerleft=[pygame.image.load('archer/left/1.png'),pygame.image.load('archer/left/2.png'),pygame.image.load('archer/left/3.png'),pygame.image.load('archer/left/4.png'),pygame.image.load('archer/left/5.png'),pygame.image.load('archer/left/6.png'),pygame.image.load('archer/left/7.png'),pygame.image.load('archer/left/8.png')]
archerright=[pygame.image.load('archer/right/1.png'),pygame.image.load('archer/right/2.png'),pygame.image.load('archer/right/3.png'),pygame.image.load('archer/right/4.png'),pygame.image.load('archer/right/5.png'),pygame.image.load('archer/right/6.png'),pygame.image.load('archer/right/7.png'),pygame.image.load('archer/right/8.png')]
archerdeath=[pygame.image.load('archer/death/1.png'),pygame.image.load('archer/death/2.png'),pygame.image.load('archer/death/3.png'),pygame.image.load('archer/death/4.png'),pygame.image.load('archer/death/5.png'),pygame.image.load('archer/death/6.png'),pygame.image.load('archer/death/7.png'),pygame.image.load('archer/death/8.png')]
archerback=[pygame.image.load('archer/back/1.png'),pygame.image.load('archer/back/2.png'),pygame.image.load('archer/back/3.png'),pygame.image.load('archer/back/4.png'),pygame.image.load('archer/back/5.png'),pygame.image.load('archer/back/6.png'),pygame.image.load('archer/back/7.png'),pygame.image.load('archer/back/8.png')]
archeraback=[pygame.image.load('archer/aback/1.png'),pygame.image.load('archer/back/2.png'),pygame.image.load('archer/aback/3.png'),pygame.image.load('archer/aback/4.png'),pygame.image.load('archer/aback/5.png'),pygame.image.load('archer/aback/6.png'),pygame.image.load('archer/aback/7.png'),pygame.image.load('archer/aback/8.png')]

myhp=1000
hp=1000
class clan():
    def __init__(self,x,y):
        
        self.x=x
        self.y=y
        self.hp=250
        self.hitbox=(self.x+45,self.y,250,self.y+100)
    
    def hit(self,a):
        if a[1] <=self.hitbox[3] :
            global hp
            hp-=5
    def hitt(self,a):
        if a[1] <=self.hitbox[3] :
            global myhp
            myhp-=5
    def hit1(self,a):
        if a[1] <=self.hitbox[3] :
            global hp
            hp-=5
    def hitt1(self,a):
        if a[1] <=self.hitbox[3] :
            global myhp
            myhp-=10
    def hit2(self,a):
        if a[1] <=self.hitbox[3] :
            global hp
            hp-=15
    def hitt2(self,a):
        if a[1] <=self.hitbox[3] :
            global myhp
            myhp-=15
           
fire=[]
mace=[]
sward=[]
blade=[]
arrowse=[]
arrows=[]
stones=[]
stonese=[]
class Aarcher():
    def __init__(self,x,y):
        self.x=x
        self.y=y
        self.speed=5/2
        self.walkcountright=0
        self.walkcountleft=0
        self.walkcountfront=0
        self.walkcountback=0
        self.atkcountright=0
        self.atkcountleft=0
        self.atkcountfront=0
        self.atkcountback=0
        self.deathcout=0
        self.hp=20
        self.hitbox=(self.x,self.y-15,self.x+20,self.y+15)
    def draw(self,window):
        if self.y>=150:
            if self.walkcountfront +1 >=24:
                self.walkcountfront=0
            window.blit(arabarcherfront[self.walkcountfront//3],(self.x,self.y))
            self.walkcountfront+=1
            self.y-=self.speed
        elif self.x < 390:
            if self.walkcountright +1 >=24:
                self.walkcountright=0
            window.blit(arabarcherright[self.walkcountright//3],(self.x,self.y))
            self.walkcountright+=1
            self.x+=self.speed
        
        elif self.x >590:
            if self.walkcountleft +1 >=24:
                self.walkcountleft=0
            window.blit(arabarcherleft[self.walkcountleft//3],(self.x,self.y))
            self.walkcountleft+=1
            self.x-=self.speed
        else:
            if self.atkcountfront +1 >=24:
                self.atkcountfront=0
            window.blit(arabarcherafront[self.atkcountfront//3],(self.x,self.y))
            self.atkcountfront+=1
            if self.atkcountfront==21:
                a=(self.x+50,self.y)
                arrows.append(a)
        pygame.draw.rect(window,(255,0,0),(self.x+40,self.y +23,20,2))
        pygame.draw.rect(window,(0,120,0),(self.x+40,self.y +23,self.hp,2))
    def arrow(self):
        for k in arrows:
                x=k[0]
                y=k[1]
                if y >115 :
                    pygame.draw.line(window,(120,120,120),(x,y),(x,y+5))
                    y-=4
                    c=arrows.index(k)
                    arrows[c]=(x,y)
                    
            
                    
                else:
                    arrows.pop(arrows.index(k))

class assassin():
    def __init__(self,x,y):
        self.x=x
        self.y=y
        self.speed=1
        self.walkcountright=0
        self.walkcountleft=0
        self.walkcountfront=0
        self.walkcountback=0
        self.atkcountright=0
        self.atkcountleft=0
        self.atkcountfront=0
        self.atkcountback=0
        self.deathcout=0
        self.hp=30
        self.hitbox=(self.x,self.y,self.x+20,self.y+30)
    def draw(self,window):

        if self.y<=330:
            if self.walkcountback +1 >=24:
                self.walkcountback=0
            window.blit(assassinback[self.walkcountback//3],(self.x,self.y))
            self.walkcountback+=1
            self.y+=self.speed
        elif self.x < 390:
            if self.walkcountright +1 >=24:
                self.walkcountright=0
            window.blit(assassinright[self.walkcountright//3],(self.x,self.y))
            self.walkcountright+=1
            self.x+=self.speed
        
        elif self.x >590:
            if self.walkcountleft +1 >=24:
                self.walkcountleft=0
            window.blit(assassinleft[self.walkcountleft//3],(self.x,self.y))
            self.walkcountleft+=1
            self.x-=self.speed
        else:
            if self.atkcountback +1 >=24:
                self.atkcountback=0
            window.blit(assassinaback[self.atkcountback//3],(self.x,self.y))
            self.atkcountback+=1
            if self.atkcountback==21:
                a=(self.x+55,self.y+70)
                blade.append(a)
        pygame.draw.rect(window,(0,0,0),(self.x+35,self.y +23,20,2))
        pygame.draw.rect(window,(255,120,0),(self.x+35,self.y +23,self.hp,2))

class monk():
    def __init__(self,x,y):
        self.x=x
        self.y=y
        self.speed=2
        self.walkcountright=0
        self.walkcountleft=0
        self.walkcountfront=0
        self.walkcountback=0
        self.atkcountright=0
        self.atkcountleft=0
        self.atkcountfront=0
        self.atkcountback=0
        self.deathcout=0
        self.hp=25
        self.hitbox=(self.x,self.y,self.x+20,self.y+30)
    def draw(self,window):

        if self.y<=330:
            if self.walkcountback +1 >=24:
                self.walkcountback=0
            window.blit(monkback[self.walkcountback//3],(self.x,self.y))
            self.walkcountback+=1
            self.y+=self.speed
        elif self.x < 390:
            if self.walkcountright +1 >=24:
                self.walkcountright=0
            window.blit(monkright[self.walkcountright//3],(self.x,self.y))
            self.walkcountright+=1
            self.x+=self.speed
        
        elif self.x >590:
            if self.walkcountleft +1 >=24:
                self.walkcountleft=0
            window.blit(monkleft[self.walkcountleft//3],(self.x,self.y))
            self.walkcountleft+=1
            self.x-=self.speed
        else:
            if self.atkcountback +1 >=24:
                self.atkcountback=0
            window.blit(monkaback[self.atkcountback//3],(self.x,self.y))
            self.atkcountback+=1
            if self.atkcountback==21:
                a=(self.x+55,self.y+70)
                fire.append(a)
        pygame.draw.rect(window,(0,0,0),(self.x+36,self.y +23,20,2))
        pygame.draw.rect(window,(255,0,0),(self.x+36,self.y +23,self.hp,2))

class archer():
   
    def __init__(self,x,y):
        self.x=x
        self.y=y
        self.speed=5/2
        self.walkcountright=0
        self.walkcountleft=0
        self.walkcountfront=0
        self.walkcountback=0
        self.atkcountright=0
        self.atkcountleft=0
        self.atkcountfront=0
        self.atkcountback=0
        self.deathcout=0
        self.hp=20
        self.hitbox=(self.x,self.y,self.x+20,self.y+30)
    def draw(self,window):

        if self.y<=285:
            if self.walkcountback +1 >=24:
                self.walkcountback=0
            window.blit(archerback[self.walkcountback//3],(self.x,self.y))
            self.walkcountback+=1
            self.y+=self.speed
        elif self.x < 390:
            if self.walkcountright +1 >=24:
                self.walkcountright=0
            window.blit(archerright[self.walkcountright//3],(self.x,self.y))
            self.walkcountright+=1
            self.x+=self.speed
        
        elif self.x >590:
            if self.walkcountleft +1 >=24:
                self.walkcountleft=0
            window.blit(archerleft[self.walkcountleft//3],(self.x,self.y))
            self.walkcountleft+=1
            self.x-=self.speed
        else:
            if self.atkcountback +1 >=24:
                self.atkcountback=0
            window.blit(archeraback[self.atkcountback//3],(self.x,self.y))
            self.atkcountback+=1
            if self.atkcountback==21:
                a=(self.x+55,self.y+70)
                arrowse.append(a)
        pygame.draw.rect(window,(0,0,0),(self.x+40,self.y +23,20,2))
        pygame.draw.rect(window,(255,0,0),(self.x+40,self.y +23,self.hp,2))
    def arrowe(self):
        for k in arrowse:
                x=k[0]
                y=k[1]
                if y < 380 :
                    pygame.draw.line(window,(120,120,120),(x,y),(x,y-5))
                    y+=4
                    c=arrowse.index(k)
                    arrowse[c]=(x,y)
                    
            
                    
                else:
                    arrowse.pop(arrowse.index(k))                
  
            
            

        
class Maceman():
    def __init__(self,x,y):
        self.x=x
        self.speed=2
        self.y=y
        self.walkcountright=0
        self.walkcountleft=0
        self.walkcountfront=0
        self.walkcountback=0
        self.atkcountright=0
        self.atkcountleft=0
        self.atkcountfront=0
        self.atkcountback=0
        self.deathcout=0
        self.hitbox=(self.x+20,self.y+5,10,30)
        self.hp=25
        
    def draw(self,window):
        if self.y>=100:
            if self.walkcountfront +1 >=24:
                self.walkcountfront=0
            window.blit(macemanfront[self.walkcountfront//3],(self.x,self.y))
            self.walkcountfront+=1
            self.y-=self.speed
            
        elif self.x < 390:
            if self.walkcountright +1 >=24:
                self.walkcountright=0
            window.blit(macemanright[self.walkcountright//3],(self.x,self.y))
            self.walkcountright+=1
            self.x+=self.speed
        elif self.x >590:
            if self.walkcountleft +1 >=24:
                self.walkcountleft=0
            window.blit(macemanleft[self.walkcountleft//3],(self.x,self.y))
            self.walkcountleft+=1
            self.x-=self.speed
        else:
            if self.atkcountfront +1 >=24:
                self.atkcountfront=0
            window.blit(macemanafront[self.atkcountfront//3],(self.x,self.y))
            
            self.atkcountfront+=1
            if self.atkcountfront==21:
                a=(self.x+35,self.y+25)
                mace.append(a)
        pygame.draw.rect(window,(255,0,0),(self.x+36,self.y +23,25,2))
        pygame.draw.rect(window,(0,120,0),(self.x+36,self.y +23,self.hp,2))
    
        
class swardsman():
    def __init__(self,x,y):
        self.x=x
        self.y=y
        self.speed=1
        self.walkcountright=0
        self.walkcountleft=0
        self.walkcountfront=0
        self.walkcountback=0
        self.atkcountright=0
        self.atkcountleft=0
        self.atkcountfront=0
        self.atkcountback=0
        self.deathcout=0
        self.hp=30
        
    def draw(self,window):
        if self.y>=100:
            if self.walkcountfront +1 >=24:
                self.walkcountfront=0
            window.blit(swardsmanfront[self.walkcountfront//3],(self.x,self.y))
            self.walkcountfront+=1
            self.y-=self.speed
        elif self.x < 390:
            if self.walkcountright +1 >=24:
                self.walkcountright=0
            window.blit(swardsmanright[self.walkcountright//3],(self.x,self.y))
            self.walkcountright+=1
            self.x+=self.speed
        elif self.x >590:
            if self.walkcountleft +1 >=24:
                self.walkcountleft=0
            window.blit(swardsmanleft[self.walkcountleft//3],(self.x,self.y))
            self.walkcountleft+=1
            self.x-=self.speed
        else:
            if self.atkcountfront +1 >=24:
                self.atkcountfront=0
            window.blit(swardsmanafront[self.atkcountfront//3],(self.x,self.y))
            if self.atkcountfront==21:
                a=(self.x+35,self.y+25)
                sward.append(a)
            
            self.atkcountfront+=1
        pygame.draw.rect(window,(255,0,0),(self.x+35,self.y +23,30,2))
        pygame.draw.rect(window,(0,120,0),(self.x+35,self.y +23,self.hp,2))
class mangonel():
    def __init__(self,x,y):
        self.x=x
        self.y=y
        self.atkcountfront=0
        self.atckcountback=0
        self.death=0
        
        self.hp=40
        
    def draw(self,window):
        
        if self.atkcountfront +1 >=40:
            self.atkcountfront=0
        window.blit(mangonelafront[self.atkcountfront//5],(self.x,self.y))
        self.atkcountfront+=1
        if self.atkcountfront==27:
            a=(self.x+93,self.y+50)
            stones.append(a)
        pygame.draw.rect(window,(255,0,0),(self.x+80,self.y +45,40,2))
        pygame.draw.rect(window,(0,120,0),(self.x+80,self.y +45,self.hp,2))
    def stone(self):
        for k in stones:
                x=k[0]
                y=k[1]
                if y >135 :
                    pygame.draw.circle(window,(120,120,120),k,7,0)
                    
                    y-=6
                    c=stones.index(k)
                    stones[c]=(x,y)
                    
            
                    
                else:
                    stones.pop(stones.index(k))
    
class mangonele():
    def __init__(self,x,y):
        self.x=x
        self.y=y
        self.atkcountfront=0
        self.atkcountback=0
        self.death=0
        
        self.hp=40
        
    def draw(self,window):
        
        if self.atkcountback +1 >=40:
            self.atkcountback=0
        window.blit(mangonelaback[self.atkcountback//5],(self.x,self.y))
        self.atkcountback+=1
        if self.atkcountback==27:
            a=(self.x+93,self.y+50)
            stonese.append(a)
        pygame.draw.rect(window,(0,0,0),(self.x+80,self.y +45,40,2))
        pygame.draw.rect(window,(255,0,0),(self.x+80,self.y +45,self.hp,2))
    def stonee(self):
        for k in stonese:
                x=k[0]
                y=k[1]
                if y < 390 :
                    pygame.draw.circle(window,(120,120,120),k,7,0)
                    
                    y+=6
                    c=stonese.index(k)
                    stonese[c]=(x,y)
                    
            
                    
                else:
                    stonese.pop(stonese.index(k))
    
                    

        
clock=pygame.time.Clock()
TIME=4
WIDTH=200
time=0
timechange=0
Exitbutton=button((0,0,0),550,400,200,30,'EXIT')
fightbutton=button((0,0,0),550,300,200,30,'BEGIN THE WAR')
helpbutton=button((0,0,0),550,350,200,30,'help')

swardsmanbutton=button1(250,550,129,99,None)
archerbutton=button1(380,550,129,99,None)
macemanbutton=button1(510,550,169,99,None)
mangonelbutton=button1(680,550,171,99,None)

bg=pygame.image.load('menu.jpg') #background
pygame.display.set_caption('CRUSADER CLASH')
def drawwindow():
    window.blit(bg,(300,0))
    Exitbutton.draw(window)
    fightbutton.draw(window)
    helpbutton.draw(window)
loading=False
music=pygame.mixer.music.load('intro.mp3')
pygame.mixer.music.play(2)
while not loading:
    bg0=pygame.image.load('loading.png')
    window.blit(bg0,(300,0))
    k=pygame.time.Clock()
    k.tick(5)
    pygame.event.poll()
    k.tick(5)
        
    for event in pygame.event.get():
        position=pygame.mouse.get_pos()
        if event.type==pygame.QUIT:
            loading=True
            pygame.quit()
            quit()
    
    if time>=TIME:
        loading= True
    else:
        time+=timechange
    width=50*time
    if width>200:
        width=200
    pygame.draw.rect(window,(120,120,120),(500,400,200,20))
    pygame.draw.rect(window,(0,255,0),(500,400,width,20))
    pygame.display.flip()
    timechange=clock.tick(30)/500


playing=True
music=pygame.mixer.music.load('main.mp3')
pygame.mixer.music.play(-1)
while playing:
    pygame.display.flip()   
    drawwindow()
    pygame.display.update()
    for event in pygame.event.get():
        position=pygame.mouse.get_pos()
        if event.type==pygame.QUIT:
            playing=False
            pygame.quit()
            quit()

        if event.type==pygame.MOUSEBUTTONDOWN:
            if Exitbutton.mouseonbutton(position):
                playing=False
                pygame.quit()
                quit()

        if event.type==pygame.MOUSEMOTION:
            if Exitbutton.mouseonbutton(position):
                Exitbutton.color=(64,64,64)
            else:
                Exitbutton.color=(0,0,0)

        if event.type==pygame.MOUSEBUTTONDOWN:
            if fightbutton.mouseonbutton(position):
                playing =False
                 
                
                
        if event.type==pygame.MOUSEMOTION:
            if fightbutton.mouseonbutton(position):
                fightbutton.color=(64,64,64)
            else:
                fightbutton.color=(0,0,0)

        if event.type==pygame.MOUSEBUTTONDOWN:
            if helpbutton.mouseonbutton(position):
                print('check power point')
        if event.type==pygame.MOUSEMOTION:
            if helpbutton.mouseonbutton(position):
                helpbutton.color=(64,64,64)
            else:
                helpbutton.color=(0,0,0)
clash=True
pygame.display.update()
pygame.mixer.music.load('soundtrack2.ogg')      
pygame.mixer.music.play(0)
arabarchers=[]
mangonels=[]
macemans=[]
swardsmans=[]

clash=True
archers=[]
mangonelse=[]
assassins=[]
monks=[]

wastedtime=pygame.time.get_ticks()
while clash:
    start=str(pygame.time.get_ticks())
    timer=90000 - int(start) + wastedtime
    
    TIME=int((timer/1000) +1)
    if TIME >=0 and myhp>0 and hp>0:
        
        timer=str((timer/1000) +1)
        window.fill((0,0,0))
        bg1=pygame.image.load('clash.jpg')
        window.blit(bg1,(250,0))
        icon=pygame.image.load('icons.jpg')
        timerbutton=button1(700,10,100,40,timer +'SEC')
        timerbutton.draw(window)
        p=pygame.image.load('player.jpg')
        window.blit(p,(370,390))
        e=pygame.image.load('enemy.jpg')
        window.blit(e,(370,45))
        window.blit(icon,(250,550))
        swardsmanbutton.draw(window)
        macemanbutton.draw(window)
        mangonelbutton.draw(window)
        archerbutton.draw(window)
        home=clan(370,390)
        pygame.draw.rect(window,(255,0,0),(home.hitbox[0],home.y-10 ,250,4))
        pygame.draw.rect(window,(0,120,0),(home.hitbox[0],home.y-10 ,myhp/4,4))
        away=clan(370,45)
        pygame.draw.rect(window,(0,0,0),(away.hitbox[0],away.y-10 ,250,4))
        pygame.draw.rect(window,(255,0,0),(away.hitbox[0],away.y-10 ,hp/4,4))
        
        if len(sward)>=1:
            for i in sward:
                away.hit1(i)
                sward.pop(sward.index(i))
        if len(blade)>=1:
            for i in blade:
                home.hitt1(i)
                blade.pop(blade.index(i))
        if len(fire)>=1:
            for i in fire:
                home.hitt(i)
                fire.pop(fire.index(i))
        if len(mace)>=1:
            for i in mace:
                away.hit(i)
                mace.pop(mace.index(i))
        if len(arrows)>=1:
            for i in arrows:
                away.hit(i)
                arrows.pop(arrows.index(i))
        if len(arrowse)>=1:
            for i in arrowse:
                home.hitt(i)
                arrowse.pop(arrowse.index(i))
        if len(stones)>=1:
            away.hit2(stones[0])
                
        if len(stonese)>=1:
            home.hitt2(stones[0])
                


            

        if len(arabarchers)>0:
            for troop in arabarchers:
                troop.draw(window)
                troop.arrow()
        if len(archers)>0:
            for troop in archers:
                troop.draw(window)
                troop.arrowe()
        if len(mangonels)>0:
            for troop in mangonels:
                troop.draw(window)
                troop.stone()
        if len(mangonelse)>0:
            for troop in mangonelse:
                troop.draw(window)
                troop.stonee()
        if len(swardsmans)>0:
            for troop in swardsmans:
                troop.draw(window)
        if len(assassins)>0:
            for troop in assassins:
                troop.draw(window)
        if len(macemans)>0:
            for troop in macemans:
                troop.draw(window)
        if len(monks)>0:
            for troop in monks:
                troop.draw(window)
        pygame.display.update()
    
                    
        position=pygame.mouse.get_pos()    
        for event in pygame.event.get():
            if event.type==pygame.MOUSEBUTTONDOWN:
                if archerbutton.mouseonbutton(position):
                    if len(macemans)+len(arabarchers)+ len(swardsmans)<60:
                        archersound=pygame.mixer.Sound('arabarcher.ogg')
                        archersound.play()
                        i=Aarcher(random.randint(300,640),random.randint(310,320))
                        arabarchers.append(i)
                        b=random.randint(1,3)
                        if b==1:
                            c=monk(random.randint(370,600),random.randint(120,140))
                            monks.append(c)
                        elif b==2:
                            d=archer(random.randint(370,600),random.randint(120,140))
                            archers.append(d)
                        else:
                            e=assassin(random.randint(370,600),random.randint(120,140))
                            assassins.append(e)
                    
                   
            if event.type==pygame.MOUSEBUTTONDOWN:
                if macemanbutton.mouseonbutton(position):
                    if len(macemans)+len(arabarchers)+ len(swardsmans)<60:
                        macemansound=pygame.mixer.Sound('maceman.ogg')
                        macemansound.play()
                        i=Maceman(random.randint(300,640),random.randint(310,320))
                        macemans.append(i)
                        b=random.randint(1,3)
                        if b==1:
                            c=monk(random.randint(370,600),random.randint(120,140))
                            monks.append(c)
                        elif b==2:
                            d=archer(random.randint(370,600),random.randint(120,140))
                            archers.append(d)
                        else:
                            e=assassin(random.randint(370,600),random.randint(120,140))
                            assassins.append(e)
            if event.type==pygame.MOUSEBUTTONDOWN:
                if mangonelbutton.mouseonbutton(position):
                    if len(mangonels) <=1:
                        mangonelsound=pygame.mixer.Sound('mangonel.ogg')
                        mangonelsound.play()
                        i=mangonel(random.randint(370,600),random.randint(260,265))
                        mangonels.append(i)
                        b=mangonele(random.randint(370,600),random.randint(120,130))
                        mangonelse.append(b)
                    
                   
                
            if event.type==pygame.MOUSEBUTTONDOWN:
                if swardsmanbutton.mouseonbutton(position):
                    if len(macemans)+len(arabarchers)+ len(swardsmans)<60:
                        swardsound=pygame.mixer.Sound('swardsman.ogg')
                        swardsound.play()
                        i=swardsman(random.randint(300,640),random.randint(310,320))
                        swardsmans.append(i)
                        b=random.randint(1,3)
                        if b==1:
                            c=monk(random.randint(370,600),random.randint(120,140))
                            monks.append(c)
                        elif b==2:
                            d=archer(random.randint(370,600),random.randint(120,140))
                            archers.append(d)
                        else:
                            e=assassin(random.randint(370,600),random.randint(120,140))
                            assassins.append(e)
            if event.type==pygame.QUIT:
                clash=False
                pygame.quit()
                quit()
    elif TIME<=0:
        if myhp>=hp:
            bg=pygame.image.load('victory.png')
            window.blit(bg,(0,0))
            
            pygame.display.update()
            
            
                
        else:
            bg=pygame.image.load('defeat.png')
            window.blit(bg,(0,0))
            
            pygame.display.update()
            
    elif myhp<=0 and hp!=0:
        bg=pygame.image.load('defeat.png')
        window.blit(bg,(0,0))
        
        pygame.display.update()
        
    
    elif hp<=0:
        bg=pygame.image.load('victory.png')
        window.blit(bg,(0,0))
        pygame.display.update()
        
        
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            pygame.quit()
            quit()
        
            

            
    
    

